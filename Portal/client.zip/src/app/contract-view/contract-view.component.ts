import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contract-view',
  templateUrl: './contract-view.component.html',
  styleUrls: ['./contract-view.component.css']
})
export class ContractViewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

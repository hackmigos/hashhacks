import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import {LocalStorageService, SessionStorageService} from 'ngx-webstorage';

import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

@Injectable()
export class OtpService {
    
    private url = "http:/localhost:5000" ;
    
    constructor(private http: Http , private storage: SessionStorageService) {
        
    }
    
    send ( data ) {
        
        return this.http.post(this.url + '/otp/send' , data)
        .map(res => {
            console.log(res.json())
            // this.storage.store('result' , res.json()) ;
            return res.json() ;                                    
        })
    }
    
    verify ( data ) {
        
        return this.http.post(this.url + '/otp/verify' , data)
        .map(res => {
            console.log(res.json())
            // this.storage.store('result' , res.json()) ;
            return res.json() ;                                    
        })
    }
    
}